clear all
clc
NumberOfResults = 6;
ResultsOfSpeed = zeros(NumberOfResults);
PathName = ['F:\MEI\Sozopol2012\Model\Original\Trep_Var_m\'];
speed = 10;
'Accelerations_param_damp_coeff_0.40_to_1.50_iterations_12_v=%u.txt'
for itt=1:6
    [fid,message1]=fopen([PathName FileName],'r');
end
